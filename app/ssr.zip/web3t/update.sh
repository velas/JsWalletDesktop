cp -rf ../wallet/providers ./
cp -rf ../wallet/plugins ./
cp ../wallet/math.ls ./
cp ../wallet/json-parse.ls ./
rm -rf ./node_modules/bitcore-message/node_modules