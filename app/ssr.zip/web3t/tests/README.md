### Run Tests

We cover all functionality by tests

Run Once
```sh
npm i livescript -g
```

Run Each Time
```
lsc ./main.ls
```